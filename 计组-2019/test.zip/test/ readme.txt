com_yzy.c is a comparison program. use it before delete the "\n" and " " in the end of the result.

And some folder for p4 - p7.

Good luck~

yzy
2019.07.16

--------------------------------

Histories make men wise; poets witty; the mathematics subtile; natural philosophy deep; moral grave; logic and rhetoric able to contend. Abeunt studia in morse. (Studies pass into the character.)

What character will you gain from the journey of computer organization?
It remains for you. And waiting for you.


yzy
2018.12.29